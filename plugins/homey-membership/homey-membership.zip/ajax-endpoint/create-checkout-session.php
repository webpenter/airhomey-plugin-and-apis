<?php
/*namespace Homeymembership;

require_once __DIR__ . '/../Service/StripeService.php';
$stripeService = new StripeService();

$stripe_processor_link = $_POST['stripe_processor_link'];

$planId = $_POST["planId"];
$currency = $_POST["currency"];
$postID = $_POST["postID"];

$session  = $stripeService->createCheckoutSession($planId, 1, $stripe_processor_link, $currency, $postID);

echo json_encode($session);*/
